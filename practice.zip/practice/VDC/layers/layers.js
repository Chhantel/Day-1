var wms_layers = [];

var format_VDC_0 = new ol.format.GeoJSON();
var features_VDC_0 = format_VDC_0.readFeatures(json_VDC_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_VDC_0 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_VDC_0.addFeatures(features_VDC_0);
var lyr_VDC_0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_VDC_0, 
                style: style_VDC_0,
                interactive: true,
                title: '<img src="styles/legend/VDC_0.png" /> VDC'
            });

lyr_VDC_0.setVisible(true);
var layersList = [lyr_VDC_0];
lyr_VDC_0.set('fieldAliases', {'ID_0': 'ID_0', 'ISO': 'ISO', 'NAME_0': 'NAME_0', 'ID_1': 'ID_1', 'NAME_1': 'NAME_1', 'ID_2': 'ID_2', 'NAME_2': 'NAME_2', 'ID_3': 'ID_3', 'NAME_3': 'NAME_3', 'ID_4': 'ID_4', 'NAME_4': 'NAME_4', 'VARNAME_4': 'VARNAME_4', 'TYPE_4': 'TYPE_4', 'ENGTYPE_4': 'ENGTYPE_4', });
lyr_VDC_0.set('fieldImages', {'ID_0': '', 'ISO': '', 'NAME_0': '', 'ID_1': '', 'NAME_1': '', 'ID_2': '', 'NAME_2': '', 'ID_3': '', 'NAME_3': '', 'ID_4': '', 'NAME_4': '', 'VARNAME_4': '', 'TYPE_4': '', 'ENGTYPE_4': '', });
lyr_VDC_0.set('fieldLabels', {'ID_0': 'no label', 'ISO': 'no label', 'NAME_0': 'no label', 'ID_1': 'no label', 'NAME_1': 'no label', 'ID_2': 'no label', 'NAME_2': 'no label', 'ID_3': 'no label', 'NAME_3': 'no label', 'ID_4': 'no label', 'NAME_4': 'no label', 'VARNAME_4': 'no label', 'TYPE_4': 'no label', 'ENGTYPE_4': 'no label', });
lyr_VDC_0.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});