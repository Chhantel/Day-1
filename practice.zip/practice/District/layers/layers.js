var wms_layers = [];

var format_District_0 = new ol.format.GeoJSON();
var features_District_0 = format_District_0.readFeatures(json_District_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_District_0 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_District_0.addFeatures(features_District_0);
var lyr_District_0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_District_0, 
                style: style_District_0,
                interactive: true,
                title: '<img src="styles/legend/District_0.png" /> District'
            });

lyr_District_0.setVisible(true);
var layersList = [lyr_District_0];
lyr_District_0.set('fieldAliases', {'ID_0': 'ID_0', 'ISO': 'ISO', 'NAME_0': 'NAME_0', 'ID_1': 'ID_1', 'NAME_1': 'NAME_1', 'ID_2': 'ID_2', 'NAME_2': 'NAME_2', 'ID_3': 'ID_3', 'NAME_3': 'NAME_3', 'TYPE_3': 'TYPE_3', 'ENGTYPE_3': 'ENGTYPE_3', 'NL_NAME_3': 'NL_NAME_3', 'VARNAME_3': 'VARNAME_3', });
lyr_District_0.set('fieldImages', {'ID_0': '', 'ISO': '', 'NAME_0': '', 'ID_1': '', 'NAME_1': '', 'ID_2': '', 'NAME_2': '', 'ID_3': '', 'NAME_3': '', 'TYPE_3': '', 'ENGTYPE_3': '', 'NL_NAME_3': '', 'VARNAME_3': '', });
lyr_District_0.set('fieldLabels', {'ID_0': 'no label', 'ISO': 'no label', 'NAME_0': 'no label', 'ID_1': 'no label', 'NAME_1': 'no label', 'ID_2': 'no label', 'NAME_2': 'no label', 'ID_3': 'no label', 'NAME_3': 'no label', 'TYPE_3': 'no label', 'ENGTYPE_3': 'no label', 'NL_NAME_3': 'no label', 'VARNAME_3': 'no label', });
lyr_District_0.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});